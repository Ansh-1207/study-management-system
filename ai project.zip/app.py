from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# Sample question bank (replace with your actual data)
question_bank = [
    {
        "question": "What type of bond is formed by the sharing of electrons?",
        "answers": ["Ionic", "Covalent", "Metallic", "Hydrogen"],
        "correct_answer": "Covalent",
        "related_concept": "Covalent Bonding"
    },
    {
        "question": "Which force is responsible for holding ions together in an ionic compound?",
        "answers": ["Gravitational", "Electrostatic", "Magnetic", "Nuclear"],
        "correct_answer": "Electrostatic",
        "related_concept": "Ionic Bonding"
    },
    # Add more questions...
]

# Sample chapter content (replace with your NCERT content)
chapter_content = """
Chemical bonds are forces that hold atoms together...
... (Your NCERT chapter content here) ...
"""

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/content')
def get_content():
    return jsonify({"content": chapter_content})

@app.route('/question')
def get_question():
    question = question_bank[0]  # Get the first question for now
    return jsonify(question)

@app.route('/submit_answer', methods=['POST'])
def submit_answer():
    data = request.get_json()
    student_answer = data.get('answer')
    question_index = 0 # get the first question for now.
    correct_answer = question_bank[question_index]['correct_answer']

    correct = student_answer == correct_answer

    return jsonify({"correct": correct})

if __name__ == '__main__':
    app.run(debug=True)